class Card {
    constructor(name, text, cost, category) {
        this.name = name;
        this.text = text;
        this.cost = cost;
        this.category = category;
    }
}

module.exports = Card;