const rooms = {};

module.exports = {
    rooms
};